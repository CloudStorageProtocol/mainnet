﻿// JavaScript Document



//选项卡  myTab('.tb1>a','active','.tb2','mouseover')
function myTab(tabNav,tabActiveClass,tabCont,tabType){
	$(tabCont).eq(0).siblings(tabCont).hide();
	$(tabNav).on(tabType,function(){
		$(this).addClass(tabActiveClass).siblings().removeClass(tabActiveClass);
		var i= $(this).index();
		$(tabCont).eq(i).show().siblings(tabCont).hide();
	});

};


//返回顶部--returnTop(".div1",300);
function returnTop(Element7,speed1) {
	$(Element7).on('click',function () {
		$('html,body').animate({scrollTop: 0},speed1);	
	});
	return false;
};

//返回底部--returnBottom(".div1",300);
function returnBottom(Element8,speed2) {
	var windowHeight=document.body.clientHeight;
	$(Element8).on('click',function () {
		$('html,body').animate({scrollTop: windowHeight+'px'},speed2);
	});
	return false;
};



$(function () {
	function mySelectDown(ospan,oul,oli){
		var oSpan=$(ospan);
		var oUl=$(oul);
		var oLi=$(oli);
		oSpan.click(function(e){
			$(this).next('ul').slideDown();
			$(document).one("click", function(){
				oUl.slideUp();
			});
			e.stopPropagation();
		});
		oLi.click(function(){
			var txt=$(this).text();
			$(this).parent().parent().find('span').text(txt);
			$(this).parent().slideUp();
		});

	};
	mySelectDown('.selectDown>span',".selectDown>ul",'.selectDown>ul>li');
	
   
	
});
